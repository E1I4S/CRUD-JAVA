const API_URL = "http://localhost:8080/productos";

function cargarProductos() {
    fetch(API_URL)
        .then(res => res.json())
        .then(productos => {
            const lista = document.getElementById("lista-productos");
            lista.innerHTML = "";
            productos.forEach(p => {
                const item = document.createElement("li");
                item.textContent = `${p.nombre} (${p.estado}) - ${p.descripcion} - $${p.precio}`;
                lista.appendChild(item);
            });
        })
        .catch(err => console.error("Error al cargar productos:", err));
}

document.getElementById("formulario-producto").addEventListener("submit", function(e) {
    e.preventDefault();

    const producto = {
        nombre: document.getElementById("nombre").value,
        descripcion: document.getElementById("descripcion").value,
        cantidad: parseInt(document.getElementById("cantidad").value),
        precio: parseFloat(document.getElementById("precio").value)
    };

    fetch(API_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(producto)
    })
    .then(res => res.text())
    .then(msg => {
        alert(msg);
        cargarProductos();
        document.getElementById("formulario-producto").reset();
    })
    .catch(err => console.error("Error al crear producto:", err));
});
